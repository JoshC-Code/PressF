Hi! This is Press-f-Dev, creator of this application.

If you're unfamiliar with GitHub just click the green "code" button in the top right and then download files to download the project files as shown in the image below! 

![image](https://github.com/Press-f-Dev/Press-F/assets/157921624/2552930f-d1aa-48e7-a3ec-684b98162506)

Once downloaded, open the Press F application. You will have to click through a few folders to get to the application because of how github has packaged it. An example of what it looks like is shown below.

![image](https://github.com/Press-f-Dev/Press-F/assets/157921624/d8cdcbdf-ef16-48c9-9448-165b37da6b7c)

Once you run the application the installer will launch and prompt you to install the application on your computer. Once installed, do NOT move any of the files as that will cause the applitcation to stop working.

To use the application just click on the "Hold F Key" and the application will hhld the "F" key down for you after a short delay, the default is 3 seconds. 

![image](https://github.com/Press-f-Dev/Press-F/assets/157921624/517ec974-91a0-4f95-a631-3a9eaf385f00)

The "Delay (in seconds)" dropdown lets you decide how long of a delay there should be between clicking the Hold F button, and the application actually starting so as to give the user time to tab back to their game.

![image](https://github.com/Press-f-Dev/Press-F/assets/157921624/b3122c0a-3c87-48da-bb3f-bc657d6e795b)

Once you no longer need to hold the "F" key down, click the "Release F Key" button. and the application will stop holding the "F" key down for you.

![image](https://github.com/Press-f-Dev/Press-F/assets/157921624/1fbf1d8d-4e2f-4ddf-815a-3cf75a301758)

Quick user tip: With how Palworld reads keyboard inputs, in order for the application to work properly for you, make sure there are no items completed i.e. the "acquire" option is active. If there is an item to acquire before you run the "Hold F Key" function, your character will grab the item, but they will not start crafting/cooking. Unfortunately that's just how the game works so make sure it's clear! If you start the "Hold F Key" and the "acquire" option is active, no worries! Just click the "Release F Key" button, then acquire the item, and then click the "Hold F Key" button and you're good to go!

The application is completely free, but if the application has helped you and you'd like to support me I have a link to my buymeacoffee account in the top left corner of the application! 

Thank you for using Press F and good luck out there ethically (or unethically haha) catching and working those Pals!
